QWE RESOURCE PACK • 26.2 • QWE STYLE v2

Что добавлено:
- уникальный Requiem-кристалл QWE;
- единый набор иконок меню Муравейника;
- иконки развития, защиты, Разломов, производства, территории и хранилища;
- современный item_model формат для Minecraft 26.2.

Проверка Requiem:
/give @s minecraft:amethyst_shard[minecraft:item_model="qwe:requiem_core"]

Пак пока не требует внешнего хостинга. Для автоматической загрузки на сервер
нужен публичный URL ZIP; QWE использует ванильный fallback без пака.
